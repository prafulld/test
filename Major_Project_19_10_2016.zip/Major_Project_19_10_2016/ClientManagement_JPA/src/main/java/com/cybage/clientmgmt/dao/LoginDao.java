package com.cybage.clientmgmt.dao;

import com.cybage.clientmgmt.model.Users;

public interface LoginDao {
	Users findByUserName(String username);
}
